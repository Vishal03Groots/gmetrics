Ext.define('TP.IconWidgetAppearanceLabelOnly', {

    alias:  'tp.icon.appearance.none',

    constructor: function(config) {
        var me = this;
        Ext.apply(me, config);
    }
});
