#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

LOGINREADONLYCONTACTCFG="$HOSTPATH"/"$HOST_NAME"/login.cfg

cat << EOF >> $LOGINREADONLYCONTACTCFG
###############################################################################
#
# READONLY CONTACTS DEFINATION CONFIG FILE: $READONLYCONTACTNAME
#
###############################################################################

# Login user without receive any alert (Read Only User)
define contact {
        contact_name                    $READONLYCONTACTNAME
        alias                           $READONLYCONTACTALIAS Server Read Only Admin
        contactgroups                   $CONTACTGROUP_NAME
        host_notifications_enabled      0 ; Enable/Disable host notifications for this contact
        service_notifications_enabled   0 ; Enable/Disable service notifications for this contact
        host_notification_period        none ; If you specify "none" as period the contact will not use any timeperiod for host notifications
        service_notification_period     none ; If you specify "none" as period the contact will not use any timeperiod for service notifications
        host_notification_options       n ; If you specify n (none) as an option, the contact will not receive any type of host notifications
        service_notification_options    n ; If you specify n (none) as an option, the contact will not receive any type of service notifications
        host_notification_commands      notify-host-by-email
        service_notification_commands   notify-service-by-email
        can_submit_commands             0 ; User will not able to submit any commands on GUI
        }
EOF
