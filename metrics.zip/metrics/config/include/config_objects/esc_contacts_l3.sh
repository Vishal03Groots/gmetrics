#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

ESCCONTACTSL3CFG="$HOSTPATH"/"$HOST_NAME"/esc_contacts_l3.cfg

cat << EOF > $ESCCONTACTSL3CFG
###############################################################################
#
# ESCALATION_L3 CONTACTS DEFINATION CONFIG FILE: $ESCALATION_CONTACT_L3
#
###############################################################################

define contact {
        contact_name                    $ESCALATION_CONTACT_L3
        alias                           Level 3 Escalation Notification
        host_notifications_enabled      1 ; Enable/Disable host notifications for this contact
        service_notifications_enabled   1 ; Enable/Disable service notifications for this contact
        host_notification_period        24x7
        service_notification_period     24x7
        host_notification_options       d,u,r
        service_notification_options    w,u,c,r
        host_notification_commands      escalate-host-by-email
        service_notification_commands   escalate-service-by-email
        email                           $ESCALATION_L3_EMAIL
        #_mobilenumber                   $ESCALATION_L3_CELLNO
        #_slackid                        $ESCALATION_L3_SLACKHOOKURL
        #_rocketchatid                   $ESCALATION_L3_ROCKETCHATHOOKURL
        can_submit_commands             0 ; User will not able to submit any commands on GUI
        }
EOF

if [ "$ESCALATION_L3_CELLNO" != "" ]
then
        sed -i 's/#_mobilenumber/_mobilenumber/g' $ESCCONTACTSL3CFG;
        sed -i '/host_notification_commands      escalate-host-by-email/s/$/,escalate-host-by-sms/' $ESCCONTACTSL3CFG;
        sed -i '/service_notification_commands   escalate-service-by-email/s/$/,escalate-service-by-sms/' $ESCCONTACTSL3CFG;
fi

if [ "$ESCALATION_L3_SLACKHOOKURL" != "" ]
then
        sed -i 's/#_slackid/_slackid/g' $ESCCONTACTSL3CFG;
        sed -i '/host_notification_commands      escalate-host-by-email/s/$/,escalate-host-by-slack/' $ESCCONTACTSL3CFG;
        sed -i '/service_notification_commands   escalate-service-by-email/s/$/,escalate-service-by-slack/' $ESCCONTACTSL3CFG;
fi

if [ "$ESCALATION_L3_ROCKETCHATHOOKURL" != "" ]
then
        sed -i 's/#_rocketchatid/_rocketchatid/g' $ESCCONTACTSL3CFG;
        sed -i '/host_notification_commands      escalate-host-by-email/s/$/,escalate-host-by-rocketchat/' $ESCCONTACTSL3CFG;
        sed -i '/service_notification_commands   escalate-service-by-email/s/$/,escalate-service-by-rocketchat/' $ESCCONTACTSL3CFG;
fi

cat $ESCCONTACTSL3CFG >> "$HOSTPATH"/"$HOST_NAME"/esc_contacts.cfg
rm -rf $ESCCONTACTSL3CFG
