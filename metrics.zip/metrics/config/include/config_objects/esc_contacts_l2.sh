#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

ESCCONTACTSL2CFG="$HOSTPATH"/"$HOST_NAME"/esc_contacts.cfg

cat << EOF > $ESCCONTACTSL2CFG
###############################################################################
#
# ESCALATION_L2 CONTACTS DEFINATION CONFIG FILE: $ESCALATION_CONTACT_L2
#
###############################################################################

define contact {
        contact_name                    $ESCALATION_CONTACT_L2
        alias                           Level 2 Escalation Notification
        host_notifications_enabled      1 ; Enable/Disable host notifications for this contact
        service_notifications_enabled   1 ; Enable/Disable service notifications for this contact
        host_notification_period        24x7
        service_notification_period     24x7
        host_notification_options       d,u,r
        service_notification_options    w,u,c,r
        host_notification_commands      escalate-host-by-email
        service_notification_commands   escalate-service-by-email
        email                           $ESCALATION_L2_EMAIL
        #_mobilenumber                   $ESCALATION_L2_CELLNO
        #_slackid                        $ESCALATION_L2_SLACKHOOKURL
        #_rocketchatid                   $ESCALATION_L2_ROCKETCHATHOOKURL
        can_submit_commands             0 ; User will not able to submit any commands on GUI
        }
EOF

if [ "$ESCALATION_L2_CELLNO" != "" ]
then
        sed -i 's/#_mobilenumber/_mobilenumber/g' $ESCCONTACTSL2CFG;
        sed -i '/host_notification_commands      escalate-host-by-email/s/$/,escalate-host-by-sms/' $ESCCONTACTSL2CFG;
        sed -i '/service_notification_commands   escalate-service-by-email/s/$/,escalate-service-by-sms/' $ESCCONTACTSL2CFG;
fi

if [ "$ESCALATION_L2_SLACKHOOKURL" != "" ]
then
        sed -i 's/#_slackid/_slackid/g' $ESCCONTACTSL2CFG;
        sed -i '/host_notification_commands      escalate-host-by-email/s/$/,escalate-host-by-slack/' $ESCCONTACTSL2CFG;
        sed -i '/service_notification_commands   escalate-service-by-email/s/$/,escalate-service-by-slack/' $ESCCONTACTSL2CFG;
fi

if [ "$ESCALATION_L2_ROCKETCHATHOOKURL" != "" ]
then
        sed -i 's/#_rocketchatid/_rocketchatid/g' $ESCCONTACTSL2CFG;
        sed -i '/host_notification_commands      escalate-host-by-email/s/$/,escalate-host-by-rocketchat/' $ESCCONTACTSL2CFG;
        sed -i '/service_notification_commands   escalate-service-by-email/s/$/,escalate-service-by-rocketchat/' $ESCCONTACTSL2CFG;
fi
