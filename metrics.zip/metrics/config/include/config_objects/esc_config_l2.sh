#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

ESCCONTACTSL2CONFIGCFG="$HOSTPATH"/"$HOST_NAME"/esc_config.cfg

cat << EOF > $ESCCONTACTSL2CONFIGCFG
###############################################################################
#
# HOST ESCALATION DEFINATION CONFIG FILE: $ESCALATION_CONTACT_L2
#
###############################################################################

define hostescalation{
#        host_name              <HOST_NAME>             ; name of the host that the escalation should apply to
        hostgroup_name          $HOSTGROUP_NAME        ; name of the hostgroup that the escalation should apply to
        contacts                $ESCALATION_CONTACT_L2          ; names of the contacts that should be notified whenever there are problems (or recoveries) with this host
#       contact_groups          <CONTACTGROUP_NAME>_cg  ; name of the contact group that should be notified when the host notification is escalated. Multiple contact groups should be separated by commas
        first_notification      0 ; 1st notification receive count
        last_notification       5 ; Last notification receive count
        notification_interval   15
        escalation_period       24x7
        escalation_options      d,u,r
        }

###############################################################################
#
# SERVICE ESCALATION DEFINATION CONFIG FILE: $ESCALATION_CONTACT_L2
#
###############################################################################

define serviceescalation{
#        host_name              <HOST_NAME>             ; name of the host that the escalation should apply to
        hostgroup_name          $HOSTGROUP_NAME        ; name of the hostgroup that the escalation should apply to
        service_description     *
        contacts                $ESCALATION_CONTACT_L2          ; names of the contacts that should be notified whenever there are problems (or recoveries) with this host
#        contact_groups         <CONTACTGROUP_NAME>_cg  ; name of the contact group that should be notified when the host notification is escalated. Multiple contact groups should be separated by commas
        first_notification      2 ; 1st notification receive count
        last_notification       7 ; Last notification receive count
        notification_interval   15
        escalation_period       24x7
        escalation_options      w,u,c,r
        }
EOF
