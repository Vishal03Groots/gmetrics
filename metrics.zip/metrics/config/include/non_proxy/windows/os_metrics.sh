#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

OSMETRICSCFG="$HOSTPATH"/"$HOST_NAME"/os_metrics.cfg

cat << EOF > $OSMETRICSCFG
###############################################################################
#
# REMOTE SERVER SERVICE DEFINATION CONFIG FILE: $HOST_NAME 
#
###############################################################################
# Operating system level metrics.

# Check CPU metrics.
        
define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_load
check_command                   check_windows_metrics!check_cpu!warning='load > 80' critical='load > 90'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             ram_usage
check_command                   check_windows_metrics!check_ram!"90 98"
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# Check OS Version.

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             operating_system_version
check_command                   check_indirect_windows_metrics_v2!<PROXY_PORT>!check_os_Version
max_check_attempts              3
check_interval                  180
retry_interval                  1
check_period                    24x7
notification_interval           180
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             network_adapters
check_command                   check_indirect_windows_metrics_v2!<PROXY_PORT>!check_network
max_check_attempts              3
check_interval                  30
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             server_uptime
check_command                   check_windows_metrics!check_uptime!warning='uptime < 5m' critical='uptime < 3m'
max_check_attempts              3
check_interval                  30
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# Check Disk Partition

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             disk_partition_c
check_command                   check_windows_metrics!check_disk!"localhost C: 80 90"
max_check_attempts              3
check_interval                  60
retry_interval                  1
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# Check Service status.

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             app_service_nsclient++
check_command                   check_windows_metrics!check_service!'service=NSClient++ Monitoring Agent' "critical=state = 'stopped'"
max_check_attempts              3
check_interval                  3
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             app_service_remote_desktop_services
check_command                   check_windows_metrics!check_service!'service=Remote Desktop Services' "critical=state = 'stopped'"
max_check_attempts              3
check_interval                  3
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}
EOF
