#!/bin/bash
#######################################################
# Program: Gmetrics graph backup restore
#
# Purpose:
#  This script takes gmetrics graph backup restore
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

# Set script name
#######################################################
SCRIPTNAME=$(basename $0)

# Import Hostname
#######################################################
HOSTNAME=$(hostname)

# Logfile
#######################################################
LOGDIR="/var/log/groots/gmetrics/"
LOGFILE=$LOGDIR/"$SCRIPTNAME".log

if [ ! -d $LOGDIR ]
then
    mkdir -p $LOGDIR
elif [ ! -f $LOGFILE ]
then
    touch $LOGFILE
fi

# Logger function
#######################################################

log () {

    while read line; do echo "[`date +"%Y-%m-%dT%H:%M:%S,%N" | rev | cut -c 7- | rev`][$SCRIPTNAME]: $line"| tee -a $LOGFILE 2>&1 ; done
}

# Usage details
#######################################################
if [ "${1}" = "--help" -o "${#}" = "0" ];
then
       echo "Usage: $SCRIPTNAME -c [Mobile Number] -t [Notify Type] -m [Input Message]

        OPTION                  DESCRIPTION
        ----------------------------------
        --help                  Help
        -cn [Moblie Number]      Recipient Mobile Number to Receive Message.
        -ts [Notify Type]        Notification tyep set is service or host.
        ----------------------------------

        Usage: 
FOR HOSTS:
        $SCRIPTNAME -cn \"\$_CONTACTMOBILENUMBER\$\" -ts \"host\" -sd \"\$SHORTDATETIME\$\" -nt \"\$NOTIFICATIONTYPE\$\" -rh \"\$HOSTNAME\$\" -hs \"\$HOSTSTATE\$\" -ho \"\$HOSTOUTPUT\$\"

FOR SERVICES:
        $SCRIPTNAME -cn \"\$_CONTACTMOBILENUMBER\$\" -ts \"service\" -sd \"\$SHORTDATETIME\$\" -nt \"\$NOTIFICATIONTYPE\$\" -rh \"\$HOSTNAME\$\" -sc \"\$SERVICEDESC\$\" -st \"\$SERVICESTATE\$\" -ds \"\$SERVICEDURATION\$\"

Note : \"Mobile Number without prefix \"+91\" and Message should be in Double Quote\"
And approved by DLT";
       exit 3;
fi

#######################################################
# Get user-given variables
#######################################################

while getopts "c:t:m:" OPT
do
        case $OPT in
        c) MOBILENO="$OPTARG" ;;
        t) SMSTYPE="$OPTARG" ;;
        m) NOTIFICATION="$OPTARG" ;;
        *) echo "Usage: 
FOR HOSTS:
        $SCRIPTNAME -cn \"$_CONTACTMOBILENUMBER$\" -ts host -sd \"$SHORTDATETIME$\" -nt \"$NOTIFICATIONTYPE$\" -rh \"$HOSTNAME$\" -hs \"$HOSTSTATE$\" -ho \"$HOSTOUTPUT$\"

FOR SERVICES:
        $SCRIPTNAME -cn \"$_CONTACTMOBILENUMBER$\" -ts host -sd \"$SHORTDATETIME$\" -nt \"$NOTIFICATIONTYPE$\" -rh \"$HOSTNAME$\" -sc \"$SERVICEDESC$\" -st \"$SERVICESTATE$\" -ds \"$SERVICEDURATION$\"
"
           exit 3
           ;;
        esac
done

# Get user-given variables
#######################################################
POSITIONAL=()
while [ $# -gt 0 ]
do
ARGS="$1"

case $ARGS in
    -cn|--cellno)
    MOBILENO="$2"
    shift # past argument
    shift # past value
    ;;
    -ts|--typesms)
    SMSTYPE="$2"
    shift # past argument
    shift # past value
    ;;
    -sd|--shortdatetime)
    SHORTDATETIME="$2"
    shift # past argument
    shift # past value
    ;;
    -nt|--notificationtype)
    NOTIFICATIONTYPE="$2"
    shift # past argument
    shift # past value
    ;;
    -rh|--remotehostname)
    RHOSTNAME="$2"
    shift # past argument
    shift # past value
    ;;
    -hs|--hoststate)
    HOSTSTATE="$2"
    shift # past argument
    shift # past value
    ;;
    -ho|--hostoutput)
    HOSTOUTPUT="$2"
    shift # past argument
    shift # past value
    ;;
    -sc|--servicedesc)
    SERVICEDESC="$2"
    shift # past argument
    shift # past value
    ;;
    -st|--servicestate)
    SERVICESTATE="$2"
    shift # past argument
    shift # past value
    ;;
    -ds|--serviceduration)
    SERVICEDURATION="$2"
    shift # past argument
    shift # past value
    ;;
    *)    # unknown option
    echo "Usage: 
FOR HOSTS:
	$SCRIPTNAME -cn \"$_CONTACTMOBILENUMBER$\" -ts host -sd \"$SHORTDATETIME$\" -nt \"$NOTIFICATIONTYPE$\" -rh \"$HOSTNAME$\" -hs \"$HOSTSTATE$\" -ho \"$HOSTOUTPUT$\"

FOR SERVICES:
	$SCRIPTNAME -cn \"$_CONTACTMOBILENUMBER$\" -ts host -sd \"$SHORTDATETIME$\" -nt \"$NOTIFICATIONTYPE$\" -rh \"$HOSTNAME$\" -sc \"$SERVICEDESC$\" -st \"$SERVICESTATE$\" -ds \"$SERVICEDURATION$\""
    POSITIONAL+=("$1") # save it in an array for later
    shift # past argument
    ;;
esac
done

#######################################################
# Main Logic
#######################################################
DATE=`date +%Y-%m-%dT%H-%M-%S`
TMPFILE="/tmp/$SCRIPTNAME.log"

# SMS Gateway ID and Password.
#######################################################
USERNAME="grootssoftwaretechnologies"
PASSWORD="7350288880"
SENDER="GMAPPS"
SMSAPIURL="http://api.bulksmsgateway.in/sendmessage.php"
TEMPLATEID_HOST="1507162868658872329"
TEMPLATEID_SERVICE="1507163178285769226"
TEMPLATE_MESSAGE_HOST="Groots-{#var#} NOTIFYTYPE: {#var#} on HOST: {#var#}{#var#} State: {#var#} INFO: {#var#}{#var#}"
TEMPLATE_MESSAGE_SERVICE="Groots-{#var#} NOTIFYTYPE: {#var#} for {#var#}{#var#} SERVICE: {#var#}{#var#} STATE: {#var#} for {#var#}"

# Verify message length less than 16 char
#######################################################
ERRMSG="No output on stdout OR CHECK_METRICS: Error"
SERVICEERRMSG="CHECK_METRICS:"
HOSTERRMSG=`echo $HOSTOUTPUT| egrep -o "No output on stdout|CHECK_METRICS:"`
SERVICEERRMSG=`echo $SERVICEDESC| egrep -o "CHECK_METRICS:"`
if [ "No output on stdout" = "$HOSTERRMSG" ] || [ "CHECK_METRICS:" = "$HOSTERRMSG" ]
then
	HOSTOUTPUT="$ERRMSG"
elif [ "CHECK_METRICS:" = "$SERVICEERRMSG" ] 
then
	SERVICEDESC="$SERVICEERRMSG Error"
else
	HOSTOUTPUT=$HOSTOUTPUT
	SERVICEDESC=$SERVICEDESC
fi

# Validate input parameters
#######################################################
if [ "$SMSTYPE" = "host" ]
then
	# Host notification message
	HOSTMESSAGE="Groots-$SHORTDATETIME NOTIFYTYPE: $NOTIFICATIONTYPE on HOST: $RHOSTNAME STATE: $HOSTSTATE INFO: $HOSTOUTPUT"
        echo "#######################################################" | log
        echo "SMS sending for host: MOBILENO: $MOBILENO SMSTYPE: $SMSTYPE SHORTDATE: $SHORTDATETIME NOTIFYTYPE: $NOTIFICATIONTYPE on HOST: $RHOSTNAME STATE: $HOSTSTATE INFO: $HOSTOUTPUT" | log
        wget --no-check-certificate -O $TMPFILE "$SMSAPIURL?user=$USERNAME&password=$PASSWORD&mobile=$MOBILENO&message=$HOSTMESSAGE&sender=$SENDER&type=3&template_id=$TEMPLATEID_HOST" 2>&1 | tee -a $LOGFILE 2>&1
	cat $TMPFILE >> $LOGFILE 2>&1
elif [ "$SMSTYPE" = "service" ]
then
	# Service noification message
	SERVICEMESSAGE="Groots-$SHORTDATETIME NOTIFYTYPE: $NOTIFICATIONTYPE for $RHOSTNAME SERVICE: $SERVICEDESC STATE: $SERVICESTATE for $SERVICEDURATION"
	echo "#######################################################" | log
        echo "SMS sending for service: MOBILENO: $MOBILENO SMSTYPE: $SMSTYPE SHORTDATE: $SHORTDATETIME NOTIFYTYPE: $NOTIFICATIONTYPE for $RHOSTNAME SERVICE: $SERVICEDESC STATE: $SERVICESTATE for $SERVICEDURATION" | log
        wget --no-check-certificate -O $TMPFILE "$SMSAPIURL?user=$USERNAME&password=$PASSWORD&mobile=$MOBILENO&message=$MESSAGE&sender=$SENDER&type=3&template_id=$TEMPLATEID_SERVICE" 2>&1 | tee -a $LOGFILE 2>&1
	cat $TMPFILE >> $LOGFILE 2>&1
else
        echo "#######################################################" | log
        echo "Entered SMS template is invalid please check sms template" | log
        exit 3;
fi

# End Main Logic.
#######################################################
