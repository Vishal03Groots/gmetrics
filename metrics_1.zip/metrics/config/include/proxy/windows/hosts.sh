#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

REMOTEHOSTSCFG="$HOSTPATH"/"$HOST_NAME"/hosts.cfg

cat << EOF > $REMOTEHOSTSCFG
###############################################################################
#
# REMOTE SERVER DEFINATION CONFIG FILE: $HOST_NAME 
#
###############################################################################

define host {
        use                             generic-host,host-pnp  ; Inherit default values
        host_name                       $HOST_NAME            ; Inherit default values from a template, For example : Grootsmail, refer
        alias                           $HOSTNAME_ALIAS       ; A longer name for the server, For example : Grootsmail, It shows in SMS Alert.
        display_name                    $HOST_NAME            ; Inherit default values from a template, For example : Grootsmail, refer
        address                         $SERVER_PUBLIC_IP     ; IP address of Remote Linux host, For example : 1.23.45.67.
        #parents                         $PARENTHOSTS           ; Parent hostname if it down then this server goes in UNREACHABLE state instead DOWN.
        #hostgroups                      $HOSTGROUP_NAME        ; Host group name
        check_command                   check_windows_indirect_metrics!$PROXYPORT!check_host!'127.0.0.1 5 3000,70 4000,80'
        max_check_attempts              1
        check_interval                  10
        retry_interval                  5
        check_period                    24x7
        process_perf_data               1
        contact_groups                  $CONTACTGROUP_NAME ; Name of contact group, For example : Grootscontact, It uses in SMS and EMAIL Alert.
        notification_interval           15
        first_notification_delay        0
        notification_period             24x7
        notification_options            d,u,r
        notifications_enabled           0
        register                        1                       ; Host Enable/Disable in Gmetrics Monitoring
}
EOF

if [ "$PARENTHOSTS" != '' ] || [ ! -z "$PARENTHOSTS" ]
then
	sed -i 's/#parents/parents/g' $REMOTEHOSTSCFG
else
	sed -i 's/#parents                          /#parents                         PARENTHOSTS/g' $REMOTEHOSTSCFG	
fi

if [ "$HOSTGROUP_NAME" != '' ] || [ ! -z "$HOSTGROUP_NAME" ]
then
	sed -i 's/#hostgroups/hostgroups/g' $REMOTEHOSTSCFG
else
	sed -i 's/#hostgroups                       /#hostgroups                      HOSTGROUP_NAME/g' $REMOTEHOSTSCFG
fi
