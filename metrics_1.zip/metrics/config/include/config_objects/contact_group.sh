#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

CONTACTGROUPCFG="$HOSTPATH"/"$HOST_NAME"/contact_group.cfg

cat << EOF > $CONTACTGROUPCFG
###############################################################################
#
# CONTACTS GROUP DEFINATION CONFIG FILE: $CONTACTGROUP_NAME
#
###############################################################################

define contactgroup{
        contactgroup_name       $CONTACTGROUP_NAME
        alias                   $CONTACTGROUP_ALIAS Administrators
	contactgroup_members	manager_cg
        }

EOF
