#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

HOSTSERVICEGROUPCFG="$HOSTPATH"/"$HOST_NAME"/hostgroup_and_servicegroup.cfg

cat << EOF > $HOSTSERVICEGROUPCFG
###############################################################################
#
# HOST GROUP DEFINATION CONFIG FILE: $HOSTGROUP_NAME
#
###############################################################################

define hostgroup{
        hostgroup_name          $HOSTGROUP_NAME                ; The name of the hostgroup
        alias                   $HOSTGROUP_ALIAS                       ; Long name of the group
        }

###############################################################################
#
# SERVICE GROUP DEFINATION CONFIG FILE: $SERVICEGROUP_NAME
#
###############################################################################

define servicegroup{
        servicegroup_name       $SERVICEGROUP_NAME     ; The name of the servicegroup
        alias                   $SERVICEGROUP_ALIAS                    ; Long name of the group
        }
EOF

if [ "$HOSTGROUP_NAME" = "" ]
then
	sed -i '7,10 s/^/#/' $HOSTSERVICEGROUPCFG
elif [ "$SERVICEGROUP_NAME" = "" ]
then
	sed -i '18,21 s/^/#/' $HOSTSERVICEGROUPCFG
else
	echo "hosts and service group added"	
fi
