#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

LOGINCONTACTCFG="$HOSTPATH"/"$HOST_NAME"/login.cfg

cat << EOF > $LOGINCONTACTCFG
###############################################################################
#
# LOGIN CONTACTS DEFINATION CONFIG FILE: $CONTACTNAME
#
###############################################################################
# Login user with receive email alert

define contact {
        contact_name                    $CONTACTNAME
        alias                           $CONTACTALIAS Server Admin
        contactgroups                   $CONTACTGROUP_NAME
        host_notifications_enabled      1 ; Enable/Disable host notifications for this contact
        service_notifications_enabled   1 ; Enable/Disable service notifications for this contact
        host_notification_period        24x7
        service_notification_period     24x7
        host_notification_options       d,u,r
        service_notification_options    w,u,c,r
        host_notification_commands      notify-host-by-email
        service_notification_commands   notify-service-by-email
        email                           $EMAILID
        #_mobilenumber                   $CELLNO
        #_slackid                        $SLACKHOOKURL
        #_rocketchatid                   $ROCKETCHATHOOKURL
        can_submit_commands             1 ; User will not able to submit any commands on GUI
        }
EOF

if [ "$CELLNO" != "" ]
then
	sed -i 's/#_mobilenumber/_mobilenumber/g' $LOGINCONTACTCFG
	sed -i '/host_notification_commands      notify-host-by-email/s/$/,notify-host-by-sms/' $LOGINCONTACTCFG
	sed -i '/service_notification_commands   notify-service-by-email/s/$/,notify-service-by-sms/' $LOGINCONTACTCFG
fi

if [ "$SLACKHOOKURL" != "" ]
then
        sed -i 's/#_slackid/_slackid/g' $LOGINCONTACTCFG
        sed -i '/host_notification_commands      notify-host-by-email/s/$/,notify-host-by-slack/' $LOGINCONTACTCFG
        sed -i '/service_notification_commands   notify-service-by-email/s/$/,notify-service-by-slack/' $LOGINCONTACTCFG
fi

if [ "$ROCKETCHATHOOKURL" != "" ]
then
        sed -i 's/#_rocketchatid/_rocketchatid/g' $LOGINCONTACTCFG
        sed -i '/host_notification_commands      notify-host-by-email/s/$/,notify-host-by-rocketchat/' $LOGINCONTACTCFG
        sed -i '/service_notification_commands   notify-service-by-email/s/$/,notify-service-by-rocketchat/' $LOGINCONTACTCFG
fi
