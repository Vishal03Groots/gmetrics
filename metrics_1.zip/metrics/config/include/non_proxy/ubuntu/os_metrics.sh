#!/bin/bash
#######################################################
# Program: Gmetrics Objects Config.
#
# Purpose:
#  This script is only for Gmetrics Objects Config,
#  can be run in interactive.
#
# License:
#  This program is distributed in the hope that it will be useful,
#  but under groots software technologies @rights.
#
#######################################################

OSMETRICSCFG="$HOSTPATH"/"$HOST_NAME"/os_metrics.cfg

cat << EOF > $OSMETRICSCFG
###############################################################################
#
# REMOTE SERVER SERVICE DEFINATION CONFIG FILE: $HOST_NAME 
#
###############################################################################
# Operating system level metrics.

# 1 Check CPU metrics.

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_user_system
check_command                   check_metrics!check_cpu_user_system!'-w 80 -c 90'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_iowait
check_command                   check_metrics!check_iowait!'-w 45 -c 50'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_idle
check_command                   check_metrics!check_idle!'-w 5 -c 1'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_load
check_command                   check_metrics!check_load!'-w 25,25,25 -c 30,30,30'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_totalprocess
check_command                   check_metrics!check_total_procs!'-w 1800 -c 2000'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_zombieprocess
check_command                   check_metrics!check_zombieprocess!'-w 40 -c 50 -s Z'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_current_users
check_command                   check_metrics!check_users!'-w 5 -c 10'
max_check_attempts              3
check_interval                  15
retry_interval                  5
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_utilization
check_command                   check_metrics!check_cpu_utilization!'-w 80 -c 90'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             ram_usage
check_command                   check_metrics!check_ram!'-w 99 -c 100'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             ram_swap_usage
check_command                   check_metrics!check_swap!'-w 99 -c 100'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             cpu_utilized_process
check_command                   check_metrics!check_utilized_process!'-w 80 -c 90'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# 2 Check File Size.

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             filesize_auth.log
check_command                   check_metrics!check_filesize!'-f /var/log/auth.log -s m -w 1024 -c 1620'
max_check_attempts              3
check_interval                  30
retry_interval                  15
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             filesize_syslog
check_command                   check_metrics!check_filesize!'-f /var/log/syslog -s m -w 1024 -c 1620'
max_check_attempts              3
check_interval                  30
retry_interval                  15
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# 3 Check Disk Partition

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             disk_/root
check_command                   check_metrics!check_disk!'-w 80 -c 90 -p /'
max_check_attempts              3
check_interval                  60
retry_interval                  30
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             disk_/boot
check_command                   check_metrics!check_disk!'-w 80 -c 90 -p /boot'
max_check_attempts              3
check_interval                  60
retry_interval                  30
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# 4 Check Disk Partition inode.

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             osdisk_inode_/root
check_command                   check_metrics!check_disk_inode!'-w 80 -c 90 -p /'
max_check_attempts              3
check_interval                  60
retry_interval                  30
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             osdisk_inode_/boot
check_command                   check_metrics!check_disk_inode!'-w 80 -c 90 -p /boot'
max_check_attempts              3
check_interval                  60
retry_interval                  30
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             osdisk_rwspeed_/mnt
check_command                   check_metrics!check_diskRWspeed!'-p "/mnt/" -ww 1.3 -wc 1.5 -rw 0.5 -rc 1.2'
max_check_attempts              3
check_interval                  60
retry_interval                  30
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}


define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             osdisk_io_utilization
check_command                   check_metrics!check_disk_io_utilization!'-d <DEVICENAME> -w 200 -c 400'
max_check_attempts              3
check_interval                  15
retry_interval                  1
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# 5 Check Folder Size.

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             foldersize_log
check_command                   check_metrics!check_foldersize!'-f /var/log/ -s g -w 18 -c 20'
max_check_attempts              3
check_interval                  60
retry_interval                  30
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# 6 Check DNS Status.

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             dns_status
check_command                   check_metrics!check_dns_resolve!DNS
max_check_attempts              3
check_interval                  30
retry_interval                  15
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# 7 Check Critical Sensors.

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             app_sensor_PING
check_command                   check_metrics!check_sensor_PING!'-H 127.0.0.1 -w 3000,60% -c 5000,75% -4'
max_check_attempts              3
check_interval                  3
retry_interval                  5
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             app_sensor_SSHD
check_command                   check_metrics!check_sensor!'-H 127.0.0.1 -p 22'
max_check_attempts              3
check_interval                  3
retry_interval                  5
check_period                    24x7
notification_interval           30
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

# 8 Check Service status.

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             app_service_sshd
check_command                   check_metrics!check_service!'-s sshd -u root'
max_check_attempts              3
check_interval                  3
retry_interval                  1
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             app_service_rsyslog
check_command                   check_metrics!check_service!'-s rsyslog -u root'
max_check_attempts              3
check_interval                  3
retry_interval                  1
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             app_service_cron
check_command                   check_metrics!check_service!'-s cron -u root'
max_check_attempts              3
check_interval                  3
retry_interval                  1
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}

define service{
use                             generic-service,srv-pnp
host_name                       $HOST_NAME
service_description             app_service_ufw
check_command                   check_metrics!check_service!'-s ufw -u root'
max_check_attempts              3
check_interval                  3
retry_interval                  1
check_period                    24x7
notification_interval           60
notification_period             24x7
notification_options            w,c,r,u
notifications_enabled           0
register                        1
#servicegroups                   <SERVICEGROUP_NAME>
}
EOF
